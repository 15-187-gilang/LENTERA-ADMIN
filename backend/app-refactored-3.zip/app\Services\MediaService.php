<?php

namespace App\Services;

use App\Models\Media;
use App\Repositories\Interfaces\MediaRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * -----------------------------------------------------------------------------
 * Media Service
 * -----------------------------------------------------------------------------
 *
 * Bertanggung jawab terhadap seluruh business logic
 * yang berkaitan dengan manajemen media/file.
 */
class MediaService
{
    public function __construct(
        private readonly MediaRepositoryInterface $mediaRepository
    ) {}

    /**
     * Mengambil daftar media dengan filter.
     */
    public function filter(array $filters): LengthAwarePaginator
    {
        return $this->mediaRepository->paginate($filters);
    }

    /**
     * Mengambil detail media berdasarkan ID.
     */
    public function findById(int $id): ?Media
    {
        return $this->mediaRepository->findById($id);
    }

    /**
     * Mengupload file baru dan menyimpan metadata-nya.
     */
    public function upload(UploadedFile $file, int $adminId, ?UploadedFile $thumbnail = null): Media
    {
        // Generate nama file unik dengan UUID
        $originalName = $file->getClientOriginalName();
        $size = $file->getSize();
        $extension = strtolower($file->getClientOriginalExtension());
        $filename  = Str::uuid() . '.' . $extension;
        $directory = 'media';

        // Simpan file secara manual (menghindari finfo)
        $file->move(public_path('storage/' . $directory), $filename);
        $path = $directory . '/' . $filename;

        // Buat URL publik
        $url = asset('storage/' . $path);

        $thumbnailPath = null;
        $thumbnailUrl = null;

        if ($thumbnail) {
            $thumbExtension = strtolower($thumbnail->getClientOriginalExtension());
            $thumbFilename  = 'thumb_' . Str::uuid() . '.' . $thumbExtension;
            $thumbnail->move(public_path('storage/' . $directory . '/thumbnails'), $thumbFilename);
            $thumbnailPath  = $directory . '/thumbnails/' . $thumbFilename;
            $thumbnailUrl   = asset('storage/' . $thumbnailPath);
        }

        // Tentukan mime type manual (karena finfo dimatikan)
        $mimes = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'webp' => 'image/webp',
            'gif' => 'image/gif',
            'pdf' => 'application/pdf',
        ];
        $mimeType = $mimes[$extension] ?? 'application/octet-stream';

        // Simpan metadata ke database
        $media = $this->mediaRepository->create([
            'original_name'  => $originalName,
            'filename'       => $filename,
            'mime_type'      => $mimeType,
            'extension'      => $extension,
            'size'           => $size,
            'disk'           => 'public',
            'directory'      => $directory,
            'path'           => $path,
            'url'            => $url,
            'thumbnail_path' => $thumbnailPath,
            'thumbnail_url'  => $thumbnailUrl,
            'uploaded_by'    => $adminId,
        ]);



        return $media;
    }

    /**
     * Menghapus media beserta file-nya dari storage.
     */
    public function delete(Media $media): bool
    {
        // Hapus file dari storage secara manual (menghindari finfo)
        if (file_exists(public_path('storage/' . $media->path))) {
            unlink(public_path('storage/' . $media->path));
        }

        if ($media->thumbnail_path && file_exists(public_path('storage/' . $media->thumbnail_path))) {
            unlink(public_path('storage/' . $media->thumbnail_path));
        }

        $originalName = $media->original_name;
        $mediaId      = $media->id;

        $result = $this->mediaRepository->delete($media);



        return $result;
    }
}
