<?php

namespace Database\Factories;

use App\Models\Admin;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * --------------------------------------------------------------------------
 * Admin Factory
 * --------------------------------------------------------------------------
 *
 * Digunakan untuk menghasilkan data dummy Administrator.
 */

class AdminFactory extends Factory
{
    protected $model = Admin::class;

    public function definition(): array
    {
        return [
            'name' => fake()->name(),

            'email' => fake()->unique()->safeEmail(),

            'password' => Hash::make('password'),

            'remember_token' => Str::random(10),
        ];
    }
}