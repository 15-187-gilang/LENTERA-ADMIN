<?php

namespace App\Services;

use App\Models\Setting;
use App\Repositories\Interfaces\SettingRepositoryInterface;
use Illuminate\Support\Facades\Storage;

/**
 * -----------------------------------------------------------------------------
 * Setting Service
 * -----------------------------------------------------------------------------
 *
 * Bertanggung jawab terhadap seluruh business logic
 * pengaturan website.
 */
class SettingService
{
    public function __construct(
        private readonly SettingRepositoryInterface $settingRepository
    ) {
    }

    /**
     * Mengambil data setting.
     */
    public function get(): Setting
    {
        return $this->settingRepository->get();
    }

    /**
     * Memperbarui pengaturan website.
     */
    public function update(array $data): Setting
    {
        $setting = $this->settingRepository->get();

        /*
        |--------------------------------------------------------------------------
        | Upload Logo
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['logo']) &&
            $data['logo'] !== null
        ) {

            if (
                $setting->logo &&
                file_exists(public_path('storage/' . $setting->logo))
            ) {
                unlink(public_path('storage/' . $setting->logo));
            }

            $ext = strtolower($data['logo']->getClientOriginalExtension());
            $fileName = 'settings/' . uniqid() . '.' . $ext;
            $data['logo']->move(public_path('storage/settings'), $fileName);
            $data['logo'] = $fileName;
        }

        /*
        |--------------------------------------------------------------------------
        | Upload Institution Logo
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['institution_logo']) &&
            $data['institution_logo'] !== null
        ) {

            if (
                $setting->institution_logo &&
                file_exists(public_path('storage/' . $setting->institution_logo))
            ) {
                unlink(public_path('storage/' . $setting->institution_logo));
            }

            $ext = strtolower($data['institution_logo']->getClientOriginalExtension());
            $fileName = 'settings/' . uniqid() . '.' . $ext;
            $data['institution_logo']->move(public_path('storage/settings'), $fileName);
            $data['institution_logo'] = $fileName;
        }

        /*
        |--------------------------------------------------------------------------
        | Upload Favicon
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['favicon']) &&
            $data['favicon'] !== null
        ) {

            if (
                $setting->favicon &&
                file_exists(public_path('storage/' . $setting->favicon))
            ) {
                unlink(public_path('storage/' . $setting->favicon));
            }

            $ext = strtolower($data['favicon']->getClientOriginalExtension());
            $fileName = 'settings/' . uniqid() . '.' . $ext;
            $data['favicon']->move(public_path('storage/settings'), $fileName);
            $data['favicon'] = $fileName;
        }

        /*
        |--------------------------------------------------------------------------
        | Upload Hero Image
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['hero_image']) &&
            $data['hero_image'] !== null
        ) {

            if (
                $setting->hero_image &&
                file_exists(public_path('storage/' . $setting->hero_image))
            ) {
                unlink(public_path('storage/' . $setting->hero_image));
            }

            $ext = strtolower($data['hero_image']->getClientOriginalExtension());
            $fileName = 'settings/' . uniqid() . '.' . $ext;
            $data['hero_image']->move(public_path('storage/settings'), $fileName);
            $data['hero_image'] = $fileName;
        }

        $setting = $this->settingRepository->update($data);

        return $setting;
    }
}